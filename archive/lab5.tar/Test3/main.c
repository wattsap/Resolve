
extern int k;
int main()
{
    foo();
}
