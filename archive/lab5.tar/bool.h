typedef int bool;
#define false 0
#define true 1

