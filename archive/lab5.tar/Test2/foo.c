int k = 4;

void foo()
{
}
