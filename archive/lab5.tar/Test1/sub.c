extern int myextern;
int myglobal;
static int mylocal;
int initglobal = 13;

void foo()
{
   int a;
   myextern = 3;
   goobie();
}
